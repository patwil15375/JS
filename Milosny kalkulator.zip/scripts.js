

document.addEventListener('DOMContentLoaded', (event) => {
    
    const confirmButton = document.getElementsByClassName("btn btn-danger")[0];
    
    confirmButton.addEventListener('click', () => {
        if (isNamesFilled()) {
            alert(getTextToShow(getLoveScore()));
        }
    })

})


const getLoveScore = () => Math.floor(Math.random() *100) +1;
 
const getTextToShow = (score) => {
    if (score > 70) {
        return 'Wow! Szansa wynosi ' + score + '%. Powinniście spróbować"';
    }
    if (score > 30) {
        return 'Szansa wynosi ' + score + '%.';
    }
    return 'Szansa jest równa ' + score + '%. Nie masz na co liczyć';
}

const isNamesFilled = () => {
    const names = document.getElementsByClassName("name");
    
    for (let i = 0; i < names.length; i++) {
        if (names[i].value.length < 1) {
            return false;
        }
    }
    return true;
}