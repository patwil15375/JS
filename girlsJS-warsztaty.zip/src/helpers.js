function addPostToHTML(post) {
    let parent = document.querySelector("#posts");

    let comment = document.createElement("div");
    comment.className = "post"; 
    parent.appendChild(comment); 

    let img = document.createElement("img"); 
    img.src = "src/img/chinese-duck.png"; 
    comment.appendChild(img);

    let author = document.createElement("div");
    author.className = "author"; 
    author.innerText = post.author; 

    let text = document.createElement("div");
    text.className = "text";
    text.innerText = post.text;

    let date = document.createElement("div");
    date.className = "date";
    date.innerText = post.date; 

    comment.appendChild(author);
    comment.appendChild(text);
    comment.appendChild(date); 

    document.querySelector("#posts").appendChild(comment); 


}
