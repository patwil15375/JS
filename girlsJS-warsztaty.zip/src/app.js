// API reference available at http://girlsjs.codewise.com:3000/api-docs
// const POSTS_ENDPOINT = "http://girlsjs.codewise.com:3000/api/posts";



fetch("http://girlsjs.codewise.com:3000/api/posts")
    .then(response =>response.json())
    .then(posts => posts.forEach(post => addPostToHTML(post)))  //pobiera dane z serwera, json przetwarza dane na tekst). 

document.addEventListener('DOMContentLoaded', (event) => {
 
    const postButton = document.getElementsByClassName("post-button")[0]; 
    postButton.addEventListener('click', sendNewPost);

})

function sendNewPost() {
    addPostToHTML(getNewPostData());
};

function getNewPostData() {
    let post = {};
    post.author = 'Pati';
    post.text = document.getElementById("myTextarea").value;
    post.date = '22-04.2019';

    return post;
}